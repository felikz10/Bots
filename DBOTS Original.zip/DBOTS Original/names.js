var names = {};

names.nameList = [
    "StavJ Youtube",
    "StavJ Subscribe",
    "Subscribe StavJ",
    "Skype: StavJYT",
    "StavJ Fan"
];

names.getRandomName = function() {
    return names.nameList[Math.floor((Math.random() * names.nameList.length))];
};

module.exports = names;
