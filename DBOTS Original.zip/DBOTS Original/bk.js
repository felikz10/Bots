var facebookAccounts = [{"datr":"dT3WViuVMRP7Z90AIcxIdm53","c_user":"100008791652444","xs":"171:jNIho9cEASJD1w:2:1456889823:1036"},{"datr":"u8ujVrGwOnf79YEyDrxudz-Y","c_user":"100011104415044","xs":"169:MIuzLYEWcEQ3vA:2:1456708092:-1"},{"datr":"OZzTVniw_7YdvfkfHW2m9fxT","c_user":"100002940854379","xs":"189:0XNbfu3MiTBIZQ:2:1456708709:16781"},{"datr":"nx2BVtzNTaUVjaYUOT__PPqW","c_user":"100002010184415","xs":"211:fVAd9CiJO3KTBA:2:1456621258:9136"},{"datr":"Z1rCVsaxJuvgweE1Pm795Mdb","c_user":"100004513688366","xs":"54:p3_urr8IRFzflg:2:1455690183:6759"},{"datr":"WEheVpdTMd__78WMwslq_jw7","c_user":"100010670263150","xs":"212:cmJQ7G4-VE8eow:2:1455146464:16723"},{"datr":"i-KrVkVN6IG5EaZqi-ZiTo5b","c_user":"100004318561010","xs":"53:M2W0cMgmnfyWSw:2:1454871928:11915"},{"datr":"sRGwViZB37CnHn6gTt0fOIPT","c_user":"100009466853293","xs":"138:vQrXx233D9FX1Q:2:1456881258:482"},{"datr":"sh_NViUtYRHrdIY0YuyRQAgn","c_user":"100001556779856","xs":"216:7vx5PAvaciKHaA:2:1456341234:17127"},{"datr":"fX0ZU8fkj6yW0B01Qg32FG21","c_user":"100008085763465","xs":"84:NUDzNDDSo9WxJA:2:1453953263:4893"},{"datr":"-ogkVtRBgaeBDFLC5eHNA02e","c_user":"100007306471340","xs":"151:hfLC5dLQrtkoRA:2:1456037510:-1"},{"datr":"fDTtVa8MYH9I5S9zJ84ONvBB","c_user":"100004153905616","xs":"128:uzs9-TMR4Kyfqw:2:1456318615:4228"},{"datr":"YQCaVnEHBxBOtPUZSTEpo1Dm","c_user":"100002174937817","xs":"32:rXgwn8D-NS61eQ:2:1456897585:3205"},{"datr":"NX5kVl-MjbK-oQ8ju9WklmOX","c_user":"100000515847333","xs":"178:_9lmae-T-Txgkg:2:1456239170:1023"},{"datr":"LDTWVmQq3D_8DDgClXm5yH-V","c_user":"100011483220885","xs":"186:4xgOSA-nMjC87w:2:1456899729:-1"},{"datr":"RrzAVip1vm-MWoCLh1Pqn1Hr","c_user":"100003366175931","xs":"86:FR2QchThd9Jo9w:2:1456676009:19793"},{"datr":"-D6jVqAXVRedaI6LyhAyJu46","c_user":"100007347063399","xs":"228:dhVQkjEUnTg3iw:2:1453539099:4902"},{"datr":"U7PKVpPgRrKgzKcWh8X8Lv4a","c_user":"100010755120843","xs":"134:V4W2Rp117qD8Qw:2:1456562196:6226"},{"datr":"S4K5VtskYPyfkWihZ50O8a4U","c_user":"100008076691521","xs":"102:c2nU3CHRMdurHA:2:1454998118:4533"},{"datr":"2JCJVnbfItQuO7LfZl8wIRA5","c_user":"100007356489666","xs":"187:QIXa5nCb4cvmnQ:2:1456512962:3195"},{"datr":"QOqXVhWm-kT8FrZ5czLWoWSQ","c_user":"100010411142259","xs":"39:atFd17PC4FHqWg:2:1456813220:15853"},{"datr":"d_K4Vog-mo90yoILH2l60ceV","c_user":"100006954546640","xs":"65:xTgB_OKvDoilcg:2:1456505103:10233"},{"datr":"4UW-VuKutgrut1rZnxwhRTPu","c_user":"100006582523022","xs":"27:rUtR9NpMjMBqOQ:2:1455310313:10405"},{"datr":"E86xVsBvhHO28cNy6NmVkSLG","c_user":"100001340281809","xs":"188:qumuPqeYJyqNrQ:2:1455443726:12246"},{"datr":"i1K2VkvBKYTMSRYN6XB9FN_t","c_user":"100006526052272","xs":"157:XKwPlaqMZaDS9g:2:1456796203:12195"},{"datr":"7zKzVq9lOdyByTT-IQjb5SNu","c_user":"100000179564699","xs":"34:elWv6hfK_jf54A:2:1456314772:16318"},{"datr":"GrGTVo-cZjyFr4vxiINSnXGq","c_user":"100007532852363","xs":"121:gu-f2eDFPbqBmg:2:1455345557:2031"},{"datr":"E1W9VvqN0XJNgxEvndLwJ495","c_user":"100005427401252","xs":"114:X4eM5bWaKmkydQ:2:1455248694:19804"},{"datr":"l5CDVgWbtnna_5jVJHBYVnql","c_user":"100007912307176","xs":"88:kKZ_lOJki7MZdw:2:1453360394:14021"},{"datr":"96vMVr4S4csFsT5znZIck_2H","c_user":"100002527413177","xs":"44:alhcT5ff-LfleQ:2:1456269560:16499"},{"datr":"ahERVpEDrA-rixjLh3ZkZzOV","c_user":"100009616252051","xs":"150:xDyPqoUm15gPSA:2:1454564950:-1"},{"datr":"I4-6VkwD-66B8Lm2yHi5BClJ","c_user":"100009132399444","xs":"173:TKDbDJStKbH0OQ:2:1455066933:15289"},{"datr":"HysAVlJmbnXgJVBJuawxYpSl","c_user":"100009635297729","xs":"4:2Z2z4gYy-nxPxQ:2:1442852162:13905"},{"datr":"31-oVqgqil1JVZGevkad__-N","c_user":"100004854676307","xs":"186:PpycI2lBMznOzg:2:1455600608:6300"},{"datr":"8gjVVgb5CYjxwowghLcLqqVn","c_user":"100000605033115","xs":"9:pMXRFs2VJ428cg:2:1456901451:7569"},{"datr":"GtKbVoGvq4VIrkMKKpDrzvG1","c_user":"100003555190727","xs":"155:kL8URxDMYyeOqw:2:1453052447:7873"},{"datr":"1mTVVqXmeemvr08BRBNMXwRN","c_user":"100002852003305","xs":"49:EPww5nqiqsJXVw:2:1456825576:17898"},{"datr":"aZqHVuKE1EKv_Xv2RKfjrmQj","c_user":"100010603151237","xs":"197:LuuUinfyhoih9A:2:1456368558:-1"},{"datr":"AvjUVjrRuV5s7c7O610DnssU","c_user":"100004984627620","xs":"180:yyG5YAfSSQVOeg:2:1456898056:13815"},{"datr":"7rzMVuDXlN_LX7y-mmjFrfMQ","c_user":"100009858880537","xs":"129:kjJwVKt06ubWHg:2:1456258307:9908"},{"datr":"UrPKVvXHfggbPDNiYTrg258j","c_user":"100005352945962","xs":"17:DsKt-lsfdORASA:2:1456369495:2505"},{"datr":"tvOcVsXFxkQS7uEFNIZswIvN","c_user":"100002227966560","xs":"1:Q8EZmUBUBC9ssA:2:1453307471:12420"},{"datr":"_0R7Vu9qs3xX9sn9WP1Wtvq7","c_user":"100007546352295","xs":"52:ttlVg0E075pMCw:2:1453237267:19667"},{"datr":"nwlrVv4o_KDx0_JrLeY0MttO","c_user":"100003917503224","xs":"203:2QEhdcQpBNxS8g:2:1456089425:6837"},{"datr":"wrfNVou4wPXLLsUdq4IqQq8o","c_user":"100010888323088","xs":"123:PYWFqmMxn-JPQQ:2:1456900736:-1"},{"datr":"2N0wVh7nESaRwVjwfrPXu1P8","c_user":"100006451498623","xs":"82:ekMn7Xb-dCT9ww:2:1456211527:73"},{"datr":"du_TVtMzvwQelTsXn5R03jLr","c_user":"1480432045","xs":"83:9l4LYxM0dNlm8g:2:1456734067:19685"},{"datr":"BlrVVtzroS18kEDMJ3W_CsZX","c_user":"100009254990199","xs":"214:J4vnrhPrGO6vxQ:2:1456822804:6927"},{"datr":"17TTVWbKzu7yzldM_iJsQjqS","c_user":"100001752416410","xs":"19:vUNUP8XEOxlGpg:2:1446748187:18991"},{"datr":"q7DTVuCF9Tgs-BnAp5ikbJYJ","c_user":"100003147572872","xs":"96:e-O1uhZrHa8o3A:2:1456902447:8468"},{"datr":"d5HWVoFoTkciuA-kd1ZxE0oz","c_user":"100004092414479","xs":"78:vSv9Mor6A-aljw:2:1456902589:3297"},{"datr":"5UiCVTJkeJKOnXrLxSWwMRmK","c_user":"100004699961304","xs":"206:Gqn_yrPll7QV5w:2:1456334785:17933"},{"datr":"LenVVul60jPJ166WRrothnxj","c_user":"100005460948052","xs":"113:fevxudDWAI4BDQ:2:1456859441:13867"},{"datr":"jvy_VmBa-X4Y2-WS-pHpHGQs","c_user":"100006452185224","xs":"239:YuGxsd4l9ejmOw:2:1455428908:17332"},{"datr":"zsBSVjKlzS59rPy3LsmSOmg_","c_user":"100011198673940","xs":"115:9KtZDGw9HfHTsg:2:1453270050:-1"},{"datr":"xyasVimFUj8KRaCGFlgCnAbq","c_user":"100003406634780","xs":"245:EpKJv7668zz3Dw:2:1455166228:18981"},{"datr":"lQHVVkTNe1b3BadJk0tFOhwA","c_user":"100001271421830","xs":"154:hbcb_NyraRzvgA:2:1456800158:9025"},{"datr":"7amgVjfqdW9ewrDvnIPAc9YX","c_user":"100011241879706","xs":"63:URRRmr1O7unIxQ:2:1456823708:-1"},{"datr":"I8SsVrK6kyd0785iJL3iAQV4","c_user":"100010965371976","xs":"96:VU192I2UAksBrA:2:1456086718:8053"},{"datr":"Ms7KVlwCYcIt9S_--BcxSMoR","c_user":"100005446713397","xs":"29:OujRllSsmu0aCg:2:1456131702:1962"},{"datr":"X4ugVg_AXu67bXcaapqJKuZs","c_user":"100011224578205","xs":"122:XDnbnavqrlNUlQ:2:1455175747:-1"},{"datr":"GwmNVlnl-YTwtWCpQrldEvIl","c_user":"100006146410012","xs":"128:KtCt4UWpg1E1pw:2:1454142831:19406"},{"datr":"yBzQVuU1sX1ScijZVzmWc2O6","c_user":"100009450916983","xs":"202:5PEIJbM_dBvTMA:2:1456479438:12350"},{"datr":"fVvoU0Fo2_Z-d0bTpkLXP-kn","c_user":"100011223135733","xs":"119:Ebbf3mJSJSoAdA:2:1454923989:-1"},{"datr":"254KVAV0Utd90Q-0pBX3IqMm","c_user":"100008402616826","xs":"126:rAWjVzLEZbq_UQ:2:1456631272:3140"},{"datr":"2TjPVuHygqkE3mbRa6EeL38A","c_user":"100007146723695","xs":"196:mjjKzt_7HNcgUA:2:1456582896:1375"},{"datr":"v3ocVgAs0lkWHtf2xr1lhp3V","c_user":"100009091540455","xs":"174:3GsALVZjvER_Rw:2:1455155780:13311"},{"datr":"Fwa_VrP_RqmBxhhEHYI-cdV7","c_user":"100010454474365","xs":"171:XV-CjfRb-pMnYQ:2:1456861731:6365"},{"datr":"yJvWVopW8pldmZWmLqiY1VNd","c_user":"100004870816948","xs":"233:0Kq4GLLR2DnZ0w:2:1456905248:11739"},{"datr":"_KPQVmQXm-M_84kEKFWxbvj9","c_user":"100010694927207","xs":"135:V8wG1l5Kc5-HpQ:2:1456514103:20242"},{"datr":"wp3WVlaG79Rok4kql9NLrKTG","c_user":"100007512964856","xs":"11:mySbBA-iFpQNrg:2:1456906013:2505"},{"datr":"23DWVj-RqMoQMky7FM-fJtNx","c_user":"100008494306205","xs":"70:doiPyaSpeqq62Q:2:1456894182:1851"},{"datr":"_mlVVt_uEcxey8z3c01pa79P","c_user":"100010696061935","xs":"170:4Pd35Vt_sYgC_Q:2:1453553355:-1"},{"datr":"WvEOVthP2u0EMN364MzEVMy8","c_user":"100008062786442","xs":"76:tIv89sLibkmt0w:2:1456714664:17423"},{"datr":"2M2JVI50snuOF6FBIoJfcWyb","c_user":"100008912947271","xs":"47:PuVlXgx5vz3NnQ:2:1454400256:6833"},{"datr":"Ghd4VsJ3JdgAzWBJQ8nCwXxd","c_user":"100005610510954","xs":"206:NqQ-4ZViVlzf8w:2:1452641380:20078"},{"datr":"macGVS0swcryb9rmT4N2EzSh","c_user":"100009499692130","xs":"221:joX7C10-oHYM3Q:2:1456478406:16723"},{"datr":"4TA6Vm7wnywfw2mqPGpwnycY","c_user":"100009453186618","xs":"20:InxsTFafJ-y9vg:2:1456119393:15800"},{"datr":"BObKVqnwfiYXb2oj5NNcKCYs","c_user":"100005698244390","xs":"242:9DIW0mRavuTfZQ:2:1456579100:4493"},{"datr":"nU2bVjNO4TEG41Dz8_UCjsrT","c_user":"100000958180202","xs":"164:zd13Y6D7N3bhhg:2:1455862125:18608"},{"datr":"DajRVhs9UZ16gOtsJpQg4cb2","c_user":"100006943213853","xs":"77:keHXSVZROsq1mg:2:1456764439:5127"},{"datr":"R5eSVuRtn9I3RYRhZwSCdyfj","c_user":"100007914107929","xs":"142:ibYuYim0SKihyw:2:1455025705:11556"},{"datr":"_LI8Vo4iO2Ww3h2CNcTKLYiF","c_user":"100004815697390","xs":"113:M_GGbmMa0rPn-A:2:1454575850:9649"},{"datr":"h7MeVA2RSYLyXgzDwn16Pxqj","c_user":"100010314285398","xs":"162:5amNcsOcvYvkiA:2:1455363390:-1"},{"datr":"PFSIVo-uU3fOa_33INj2oNzn","c_user":"100009795091010","xs":"142:bZBXdmnbJDp3GQ:2:1455060443:5372"},{"datr":"kXPUVsuSL-Q970U3DGo4Ds2-","c_user":"100009827024082","xs":"220:up-U_GKU2aW3-Q:2:1456804645:2099"},{"datr":"fZ6fVu_tH40Of0MNHmHJAU1t","c_user":"100011183618012","xs":"21:-6lkO6oj3H6hKA:2:1455620098:-1"},{"datr":"luDLVuBDwfoKe2UJq4IqkqSp","c_user":"100009417525796","xs":"237:LQv4WwgdWwzriQ:2:1456201901:-1"},{"datr":"Rhs3VqM7k18yGvWB7CoYrGNq","c_user":"100009558695487","xs":"254:0ZMftkmyJzdnow:2:1455345100:12803"},{"datr":"gDmiVU9b3TSRH1K6oouCjAbV","c_user":"100007075390445","xs":"17:hOnl8uL7PFZvmw:2:1436885732:13353"},{"datr":"lq92VU1EjYn6tf_0Iyt4ekA4","c_user":"100002230167403","xs":"125:fmpahf7SJSeScQ:2:1456213668:5372"},{"datr":"zU3QVoF_6CnqVutIYTKRAhbM","c_user":"100011526540561","xs":"144:K8UOMmoU9696IQ:2:1456565788:-1"},{"datr":"2oiOVtj5y6IhL-ihh1zx0LHy","c_user":"100010207543767","xs":"175:43yMJHc2zJGrnw:2:1456674129:10208"},{"datr":"MWyxUc2aHlQBiouMeaIgqabD","c_user":"100002288091095","xs":"197:v7b0SeXRKKsA0A:2:1453522473:11925"},{"datr":"LYvQVmJwIpf4oA4fZ0WgDv2r","c_user":"100002368663091","xs":"179:6OjGz_UJZBhYnw:2:1456771447:20959"},{"datr":"fmqmVtksCAvhBFJc8am5MIq6","c_user":"100009932611134","xs":"152:5DqX7zv19g09hA:2:1456850848:14840"},{"datr":"0dV5VtTsAV7IMhrZ_goF7Wvq","c_user":"100008324678805","xs":"237:kJf3IOYyy2X7yQ:2:1455479851:12581"},{"datr":"Hl9TVuzpBi_fn7BbL7jF0bMp","c_user":"100010773461399","xs":"217:uaPQtvBTOfZ88g:2:1456908627:8413"},{"datr":"LnPHVkTlCuFdf6Z9EX_nqAC2","c_user":"100004342389955","xs":"125:Faie2dASP6Osbg:2:1455958571:10208"},{"datr":"izSaVg2MHi_CuUCejrkg1_0Z","c_user":"733223618","xs":"159:qbtM5HB871jTyw:2:1454155219:10211"}];
var AgarioClient = require('agario-client');
extend = require("extend");

function facebookManager() {
    this.activeAccounts = [];
    this.usedAccounts = [];
    this.accounts = [];
}
facebookManager.prototype.generateTokens = function(settings, callback) {
    /*
     * Object   Options:
     * 
     * Boolean  owned;      default: false;
     * Boolean  maxMass;    default: false;
     * Int      minLevel;   default: 0;
     * Int      maxLevel;   default: 100;
     */
    defaultOptions = {
        owned: false,
        maxMass: false,
        minLevel: 0,
        maxLevel: 100
    };
    options = defaultOptions;
    if (typeof settings != "undefined") {
        options = extend(options, settings);
        console.log(options);
    }
    var manager = this;
    console.log("generating tokens...");
    if (this.accounts.length < 1) {
        console.log("NO ACCOUNTS TO GENERATE TOKEN");
    }
    var amountOfAccounts = this.accounts.length;
    var amountOfTriedAccounts = 0;
    //    var loopIndex = 0;
    this.accounts.map(function(cookie) {
        //skip facebook accounts that are not owned by me 
        //if we want only facebook accounts that are mine
        if (typeof cookie.owned != "undefined" && options.owned && !cookie.owned) return;

        //skip facebook accounts that are not the maximum reachable mass
        if (typeof cookie.lvl != "undefined" && options.maxMass && cookie.lvl < 34) return;

        //skip facebook accounts that are lower than this level
        if (typeof cookie.lvl != "undefined" && cookie.lvl < options.minLevel) return;

        //skip facebook accounts that are higher than this level
        if (typeof cookie.lvl != "undefined" && cookie.lvl > options.maxLevel) return;


        var account = new AgarioClient.Account();

        //Login through facebook on http://agar.io/ and copy cookies c_user,datr,xs from http://www.facebook.com/ here
        account.c_user = cookie.c_user;
        account.datr = cookie.datr;
        account.xs = cookie.xs;
        //        setTimeout(function () {
        //Request token
        account.requestFBToken(function(token, info) {
            if (token) {
                manager.activeAccounts.push({
                    cookie: cookie,
                    token: token
                });
                console.log("TOTAL TOKENS:", manager.activeAccounts.length);
            } else {
                console.log('Failed to get token!', cookie.c_user);
            }
            newAccountValidated();
        });
        //    },500 * loopIndex);
        //        loopIndex++;
    });

    function newAccountValidated() {
        amountOfTriedAccounts++;

        if (amountOfAccounts == amountOfTriedAccounts) {
            if (typeof callback == "function") {
                callback();
            }
        }
    }
};

facebookManager.prototype.generateToken = function(singleAccount) {
    var manager = this;
    [singleAccount].map(function(cookie) {
        var account = new AgarioClient.Account();

        //Login through facebook on http://agar.io/ and copy cookies c_user,datr,xs from http://www.facebook.com/ here
        account.c_user = cookie.c_user;
        account.datr = cookie.datr;
        account.xs = cookie.xs;

        //Request token
        account.requestFBToken(function(token, info) {
            if (token) {
                console.log('Got new token: ' + token);
                manager.activeAccounts.push(token);
                console.log("");
                console.log("TOTAL TOKENS:", manager.activeAccounts.length)
                console.log("");
            } else {
                console.log('Failed to get token!', cookie.c_user);
                if (info.error)
                    console.log('Request error: ' + info.error);
                if (info.res && info.res.statusCode)
                    console.log('HTTP code: ' + info.res.statusCode);
                if (info.res && info.res.headers && info.res.headers.location)
                    console.log('Redirect: ' + info.res.headers.location);
                console.log("retrying");
                manager.generateToken(cookie);
                //if(info.data) console.log('HTML: ' + info.data);
            }
        });

    });
};
facebookManager.prototype.setAccounts = function(accounts) {
    this.accounts = accounts;
}

facebookManager.prototype.hasAvailableToken = function() {
    if (this.activeAccounts.length > 0) {
        return true;
    }
    return false;
}

facebookManager.prototype.getToken = function() {
    var account = this.activeAccounts.pop();
    this.usedAccounts.push(account);
    return account.token;
};
facebookManager.prototype.returnToken = function(token) {
    for (var i = 0; i < this.usedAccounts.length; i++) {
        if (this.usedAccounts[i].token === token) {
            this.activeAccounts.push(this.usedAccounts[i]);
            this.usedAccounts.splice(i, 1);
            return;
        }

    }
    throw "No used token found for: " + token;
}

var manager = new facebookManager();
manager.setAccounts(facebookAccounts);
module.exports = manager;